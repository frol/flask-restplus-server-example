# pylint: disable=too-few-public-methods,invalid-name,missing-docstring


class GoogleAnalyticsConfig(object):
    GOOGLE_ANALYTICS_TAG = 'G-XXX'


class GoogleMapsConfig(object):
    GOOGLE_MAP_API_KEY = 'XXX'


class GoogleConfig(GoogleAnalyticsConfig, GoogleMapsConfig):
    pass


class EmailConfig(object):
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USE_SSL = False
    MAIL_USERNAME = 'dev@wildme.org'
    MAIL_PASSWORD = 'XXX'
    MAIL_DEFAULT_SENDER = ('Wild Me', 'dev@wildme.org')


class SripeProductionConfig(object):
    STRIPE_PUBLIC_KEY = 'pk_live_XXX'
    STRIPE_SECRET_KEY = 'sk_live_XXX'


class SripeDevelopmentConfig(object):
    STRIPE_PUBLIC_KEY = 'pk_test_XXX'
    STRIPE_SECRET_KEY = 'sk_test_XXX'


class EDMConfig(object):
    EDM_AUTHENTICATIONS = {
        0: {
            'username' : 'username',
            'password' : 'password',
        },
    }


class ReCaptchaConfig(object):
    RECAPTCHA_PUBLIC_KEY = 'XXX'
    RECAPTCHA_BYPASS = 'BYPASS_TOKEN'


class SecretConfig(GoogleConfig, EmailConfig, EDMConfig, ReCaptchaConfig):
    SECRET_KEY = 'SECRET_KEY'


class SecretProductionConfig(SecretConfig, SripeProductionConfig):
    pass


class SecretDevelopmentConfig(SecretConfig, SripeDevelopmentConfig):
    pass
